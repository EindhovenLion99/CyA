make
./NFA2DFA NFA.nfa Exit_NFA.nfa
more Exit_NFA.nfa