#include <iostream>
#include <cmath>
#include <fstream>
#include <sstream>
#include <string>
#include "rational_t.hpp"

using namespace std;


int main(int argc, char* argv[])
{

    if(argv[1] == NULL || argv[2] == NULL)
    {
        cout << "No hay suficientes argumentos, introduzca el fichero de entrada y/o de salida" << endl;
    }else
    {

        char *Fich_Entrada = argv[1];
        char *Fich_Salida = argv[2];

        rational_t A;

        A.Fichero_E_S(Fich_Entrada, Fich_Salida);

    }
    cout << "Ejecutando operaciones..." << endl;
    cout << "El archivo ha sido modificado con exito" << endl << endl;
    return 0;

}



