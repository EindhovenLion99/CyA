#include "rational_t.hpp"
#define precition 1e-6

rational_t::rational_t(void)  // Constructor
{
  num_ = 0, den_ = 1;
}

rational_t::rational_t(const int n, const int d)  // Constructor
{
  assert(d != 0);
  num_ = n, den_ = d;
}

// Metodo Ficheros



void rational_t::Fichero_E_S(char* file1, char* file2)
{
    ifstream Fich_Entrada(file1);
    ofstream Fich_Salida(file2);

        if(!Fich_Entrada.is_open() || !Fich_Salida.is_open())
        {
          cout << "Fallo en los archivos" << endl;
          exit(1);
        }else
        {
            char d;
            int num1; int den1; int num2; int den2, cont = 1; // Numeradores y Denominadores del fichero

            rational_t b;

            while(Fich_Entrada >> num1 >> d >> den1 >> num2 >> d >> den2)
            {
                set_num(num1); set_den(den1); b.set_num(num2); b.set_den(den2);
                rational_t sum =  add(b); rational_t sub = substract(b); rational_t mul = multiply(b); rational_t div = divide(b);

                // IMPRIMIMOS EN EL FICHERO DE SALIDA

                Fich_Salida << " ***** Par de fracciones " << cont << ": *****" << endl << endl;
                cont++;
                writ(Fich_Salida); Fich_Salida << " "; b.writ(Fich_Salida); Fich_Salida << endl << endl;

                Fich_Salida << endl << "Comparacion: " << endl << endl;

                if(greater(b)){ writ(Fich_Salida); Fich_Salida << " es mayor que "; b.writ(Fich_Salida);}
                if(less(b)){ writ(Fich_Salida); Fich_Salida << " es menor que "; b.writ(Fich_Salida);}
                if(equal(b)){ writ(Fich_Salida); Fich_Salida << " es igual que "; b.writ(Fich_Salida);}

                Fich_Salida << endl << endl << "Operaciones: " << endl << endl;

                writ(Fich_Salida); Fich_Salida << " + "; b.writ(Fich_Salida); Fich_Salida << " = "; sum.writ(Fich_Salida); Fich_Salida << endl;
                writ(Fich_Salida); Fich_Salida << " - "; b.writ(Fich_Salida); Fich_Salida << " = "; sub.writ(Fich_Salida); Fich_Salida << endl;
                writ(Fich_Salida); Fich_Salida << " * "; b.writ(Fich_Salida); Fich_Salida << " = "; mul.writ(Fich_Salida); Fich_Salida << endl;
                writ(Fich_Salida); Fich_Salida << " / "; b.writ(Fich_Salida); Fich_Salida << " = "; div.writ(Fich_Salida); Fich_Salida << endl << endl;


          }
          Fich_Entrada.close();
          Fich_Salida.close();
     }

}



// Resultado de la Fraccion

double rational_t::value() const { return double(get_num()) / get_den(); }

// Comparadores de la Fraccion

bool rational_t::equal(const rational_t& r, const double precision) const {
  return (fabs(value() - r.value()) < precision);
}

bool rational_t::greater(const rational_t& r, const double precision) const {
  return (value() - r.value() > precision);
}

bool rational_t::less(const rational_t& r, const double precision) const {
  int precision2 = precision * -1;
  return (value() - r.value() < precision2 && r.value() - value() > precision);
}

// Sobrecarga de operadores

bool rational_t::operator == (const rational_t& r) const {
	return(fabs(value()-r.value())< precition);
}

bool rational_t:: operator < (const rational_t& r) const {
	return((r.value()-value())>precition);
}

bool rational_t:: operator > (const rational_t& r) const {
	return((value()-r.value())>precition);
}

rational_t rational_t::operator +(const rational_t& r) {
	rational_t b;
	b.num_=(get_num()*r.get_den()+r.get_num()*get_den());
	b.den_=(get_den()*r.get_den());
	return b;
}

rational_t rational_t::operator -(const rational_t& r) {
	rational_t b;
	b.num_=(get_num()*r.get_den()-r.get_num()*get_den());
	b.den_=(get_den()*r.get_den());
	return b;
}

rational_t rational_t::operator *(const rational_t& r) {
	rational_t b;
	b.num_=(get_num()*r.get_num());
	b.den_=(get_den()*r.get_den());
	return b;
}

rational_t rational_t::operator /(const rational_t& r) {
	rational_t b;
	b.num_=(get_num()*r.get_den());
	b.den_=(get_den()*r.get_num());
	return b;
}

// Operaciones con Fraccion

rational_t rational_t::add(const rational_t& r) {
  rational_t add;
  add.set_num(r.get_den() * get_num() + r.get_num() * get_den());
  add.set_den(get_den() * r.get_den());
  return add;
}

rational_t rational_t::substract(const rational_t& r) {
  rational_t sub;
  sub.set_num(r.get_den() * get_num() - r.get_num() * get_den());
  sub.set_den(get_den() * r.get_den());
  return sub;
}

rational_t rational_t::multiply(const rational_t& r) {
  return rational_t(get_num() * r.get_num(), get_den() * r.get_den());
}

rational_t rational_t::divide(const rational_t& r) {
  rational_t div;
  div.set_num(get_num() * r.get_den());
  div.set_den(get_den() * r.get_num());
  return div;
}

// Writes y Reads

void rational_t::write(ostream& os) const {
  os << get_num() << "/" << get_den() << " = " << value() << endl;
}

void rational_t::writ(ostream& os) const {
  os << get_num() << "/" << get_den();
}

void rational_t::read(istream& is) {
  cout << "Numerador: ";
  is >> num_;
  cout << "Denominador: ";
  is >> den_;
  assert(den_ != 0);
}
