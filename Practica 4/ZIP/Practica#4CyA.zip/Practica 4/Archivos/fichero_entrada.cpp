/* Hola mami
que tal */
*hey

int main(){
  cout << "Ejemplo de / o //"; //Hola
} // Imprime por pantalla