
*hey

int main(){
  cout << "Ejemplo de / o //"; 
} 


2 comentarios // eliminados
1 comentarios /* */ eliminados
