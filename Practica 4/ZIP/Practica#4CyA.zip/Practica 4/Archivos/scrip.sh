rm fichero_salida.cpp
./Remover fichero_entrada.cpp fichero_salida.cpp
cat fichero_salida.cpp