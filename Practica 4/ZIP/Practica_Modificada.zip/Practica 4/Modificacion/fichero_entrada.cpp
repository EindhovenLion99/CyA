/* Hola mami
que tal */
*hey

int main()                  {
  cout << "hola"; //Hola
} // Imprime por pantalla