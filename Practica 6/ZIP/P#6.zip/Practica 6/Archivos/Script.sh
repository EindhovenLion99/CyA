rm dfa.dot
make
./DFA2dot Test_3.0.dfa dfa.dot
more dfa.dot