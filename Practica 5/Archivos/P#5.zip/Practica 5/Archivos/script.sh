rm fileout.txt
touch fileout.txt
make
./ER2Tree filein.txt fileout.txt
cat fileout.txt